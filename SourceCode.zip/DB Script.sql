CREATE DATABASE EMedicine;
USE EMedicine;

CREATE TABLE Users(ID INT IDENTITY(1,1) PRIMARY KEY, FirstName VARCHAR(100), LastName VARCHAR(100), Password VARCHAR(100),
Email VARCHAR(100), Fund DECIMAL(18,2), Type VARCHAR(100), Status INT, CreatedOn Datetime);

CREATE TABLE Medicines(ID INT IDENTITY(1,1) PRIMARY KEY, Name VARCHAR(100), Manufacturer VARCHAR(100), UnitPrice DECIMAL(18,2),
Discount DECIMAL(18,2), Quantity INT, ExpDate Datetime, ImageUrl VARCHAR(1000), Status INT)

CREATE TABLE Cart(ID INT IDENTITY(1,1) PRIMARY KEY, UserId INT, MedicineID INT, UnitPrice DECIMAL(18,2), Discount DECIMAL(18,2),
Quantity INT, TotalPrice DECIMAL(18,2))

CREATE TABLE Orders(ID INT IDENTITY(1,1) PRIMARY KEY, UserID INT, OrderNo VARCHAR(100), OrderTotal DECIMAL(18,2), OrderStatus VARCHAR(100),
CreatedOn DATETIME)

CREATE TABLE OrderItems(ID INT IDENTITY(1,1) PRIMARY KEY, OrderID INT, MedicineID INT, UnitPrice DECIMAL(18,2), Discount DECIMAL(18,2),
Quantity INT ,TotalPrice DECIMAL(18,2));

--INSERT INTO Users(FirstName, LastName, Email, Password, Type,Status,CreatedOn)
--VALUES('admin','admin','admin','admin','admin',1,GETDATE())

SELECT * FROM Users;
SELECT * FROM Cart;
SELECT * FROM Medicines;
SELECT * FROM Orders;
SELECT * FROM OrderItems;
SELECT * FROM Medicines;

--DELETE FROM Cart;
--DELETE FROM Orders;
--DELETE FROM OrderItems;

--UPDATE OrderItems SET MedicineID = 15 WHERE ID =14;
--PDATE OrderItems SET MedicineID = 16 WHERE ID =15;
--UPDATE OrderItems SET MedicineID = 17 WHERE ID =16;
--UPDATE OrderItems SET MedicineID = 18 WHERE ID =17;
--UPDATE OrderItems SET MedicineID = 19 WHERE ID =18;

--EXEC sp_viewUser 0, 'DESHWAL.03@GMAIL.COM'
--UPDATE CART SET MedicineID = 9 WHERE ID = 1; UPDATE CART SET MedicineID = 10 WHERE ID = 2;
--UPDATE CART SET MedicineID = 13 WHERE ID = 3; UPDATE CART SET MedicineID = 14 WHERE ID = 4;
--INSERT INTO Cart(UserId,MedicineID,UnitPrice,Discount,Quantity,TotalPrice) VALUES(1,1,100,5,10,450);	
--INSERT INTO Cart(UserId,MedicineID,UnitPrice,Discount,Quantity,TotalPrice) VALUES(1,2,50,10,5,237.5);	
--INSERT INTO Cart(UserId,MedicineID,UnitPrice,Discount,Quantity,TotalPrice) VALUES(2,1,100,5,1,500);	
--INSERT INTO Cart(UserId,MedicineID,UnitPrice,Discount,Quantity,TotalPrice) VALUES(2,2,200,10,2,360);
	
 INSERT INTO Medicines(Name,Manufacturer,UnitPrice,Discount,Quantity,ExpDate,ImageUrl,Status)
 VALUES('Flaxon','CIPLA',10,1,100,GETDATE(),'https://static2.medplusmart.com/products/FLEX0006_L.jpg',1)

 INSERT INTO Medicines(Name,Manufacturer,UnitPrice,Discount,Quantity,ExpDate,ImageUrl,Status)
 VALUES('VIcks','Vicks LTD',70,5,500,GETDATE(),'https://onemg.gumlet.io/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/iqio9im5oros8uvfmnhm.jpg',1)


CREATE PROC sp_register(@ID INT = NULL, @FirstName VARCHAR(100) = NULL, @LastName VARCHAR(100) = NULL, @Password VARCHAR(100) = NULL,
@Email VARCHAR(100) = NULL, @Fund DECIMAL(18,2) = NULL, @Type VARCHAR(100) = NULL, @Status INT = NULL, @ActionType VARCHAR(100) = NULL)
AS
BEGIN
	IF @ActionType = 'Add'
	BEGIN
		INSERT INTO Users(FirstName,LastName,Password,Email,Fund,Type,Status,CreatedOn)
		VALUES(@FirstName,@LastName,@Password,@Email,@Fund,@Type,@Status,GETDATE())
	END
	IF @ActionType = 'Update'
	BEGIN
		UPDATE Users SET FirstName = @FirstName,LastName = @LastName,Password = @Password
		WHERE Email = @Email;
	END
	IF @ActionType = 'AddFund'
	BEGIN
		UPDATE Users SET Fund = @Fund WHERE Email = @Email;
	END
END;

CREATE PROC sp_login(@Email VARCHAR(100), @Password VARCHAR(100))
AS
BEGIN
	SELECT * FROM Users WHERE Email = @Email AND Password = @Password AND Status = 1;
END;

CREATE PROC sp_viewUser(@ID INT = null, @Email VARCHAR(100) = null)
AS
BEGIN
	IF @ID IS NOT null AND @ID != 0
	BEGIN
		SELECT * FROM Users WHERE ID = @ID AND Status = 1;
	END
	IF @Email IS NOT null AND @Email != ''
	BEGIN
		SELECT * FROM Users WHERE Email = @Email AND Status = 1;
	END
END;

CREATE PROC sp_AddToCart(@ID INT, @Email VARCHAR(100) = null, @UnitPrice DECIMAL(18,2) = NULL, @Discount DECIMAL(18,2) = NULL
,@Quantity INT  = NULL,@TotalPrice DECIMAL(18,2)  = NULL)
AS
BEGIN
        DECLARE @UserId INT;
		DECLARE @UnitPrice_ DECIMAL(18,2);
		DECLARE @Discount_ DECIMAL(18,2);
		DECLARE @TotalPrice_ DECIMAL(18,2);
		SET @UserId = (SELECT ID FROM Users WHERE Email = @Email);
		SET @UnitPrice_ = (SELECT UnitPrice FROM Medicines WHERE ID = @ID);
		SET @Discount_ = (SELECT (UnitPrice * @Quantity * Discount)/ 100 FROM Medicines WHERE ID = @ID);
		SET @TotalPrice_ = (SELECT (UnitPrice * @Quantity) - @Discount_ FROM Medicines WHERE ID = @ID);
		
		IF NOT EXISTS(SELECT 1 FROM Cart WHERE UserId = @UserId AND MedicineID = @ID)
		BEGIN
			INSERT INTO Cart(UserId,MedicineID,UnitPrice,Discount,Quantity,TotalPrice)
			VALUES(@UserId,@ID,@UnitPrice_,@Discount_,@Quantity,@TotalPrice_);	
		END
		ELSE
		BEGIN
			UPDATE Cart SET Quantity = (Quantity + @Quantity) WHERE UserId = @UserId AND MedicineID = @ID;
		END
END

--EXEC sp_PlaceOrder 2
CREATE PROC sp_PlaceOrder(@Email VARCHAR(100))
AS
BEGIN
	DECLARE @OrderNO VARCHAR(100);
	DECLARE @OrderID INT;
	DECLARE @OrderTotal DECIMAL(18,2);
	DECLARE @UserID INT;
	SET @OrderNO =	(SELECT NEWID());
	SET @UserID = (SELECT ID FROM Users WHERE Email = @Email);

	IF OBJECT_ID('tempdb..#TempOrder') IS NOT NULL DROP TABLE #TempOrder; 
	
	SELECT * INTO #TempOrder 
	FROM Cart WHERE UserId = @UserID;

	SET @OrderTotal = (SELECT SUM(TotalPrice) from #TempOrder);

	INSERT INTO Orders(UserID,OrderNo,OrderTotal,OrderStatus,CreatedOn)
	VALUES(@UserID,@OrderNO,@OrderTotal,'Pending',GETDATE());

	SET @OrderID = (SELECT ID FROM Orders WHERE OrderNo = @OrderNO);

	INSERT INTO OrderItems(OrderID,MedicineID,UnitPrice,Discount,Quantity,TotalPrice)
	SELECT @OrderID, MedicineID,UnitPrice,Discount,Quantity,TotalPrice FROM #TempOrder;

	DELETE FROM Cart WHERE UserId = @UserID;
END



CREATE PROC sp_OrderList(@Type VARCHAR(100), @Email VARCHAR(100) = null, @ID INT)
AS
BEGIN
	IF @Type = 'Admin'
	BEGIN
		SELECT O.ID,OrderNo,OrderTotal,OrderStatus,CONVERT(NVARCHAR,O.CreatedOn,107) AS CreatedOn
		,CONCAT(U.FirstName,' ',U.LastName ) AS CustomerName
		FROM Orders O INNER JOIN Users U
		ON U.ID = O.UserID;
	END	
	IF @Type = 'User'
	BEGIN
		SELECT O.ID,OrderNo,OrderTotal,OrderStatus,CONVERT(NVARCHAR,O.CreatedOn,107) AS CreatedOn
		,CONCAT(U.FirstName,' ',U.LastName ) AS CustomerName
		FROM Orders O INNER JOIN Users U
		ON U.ID = O.UserID
		WHERE U.Email = @Email;
	END	
	IF @Type = 'UserItems'
	BEGIN
		SELECT 
		O.ID, O.OrderNo,O.OrderTotal,O.OrderStatus, M.Name AS MedicineName, M.Manufacturer,M.UnitPrice,OI.Quantity,OI.TotalPrice 
		,CONVERT(NVARCHAR,O.CreatedOn,107) AS CreatedOn ,CONCAT(U.FirstName,' ',U.LastName ) AS CustomerName
		, M.ImageUrl
		FROM Orders O 
		INNER JOIN Users U ON U.ID = O.UserID
		INNER JOIN OrderItems OI ON OI.OrderID = O.ID
		INNER JOIN Medicines M ON M.ID = OI.MedicineID
		WHERE O.ID = @ID;
	END	
END


CREATE PROC sp_AddUpdateMedicine(@ID INT = null, @Name VARCHAR(100) = null, @Manufacturer VARCHAR(100) = null,@UnitPrice DECIMAL(18,2) = null
,@Discount DECIMAL(18,2)  = null,@Quantity INT  = null,@ExpDate DATETIME  = null,@ImageUrl VARCHAR(100) = null,@Status INT = null
, @Type VARCHAR(100) = null)
AS
BEGIN
	IF @Type = 'Add'
	BEGIN
		INSERT INTO Medicines(Name,Manufacturer,UnitPrice,Discount,Quantity,ExpDate,ImageUrl,Status)
		VALUES(@Name,@Manufacturer,@UnitPrice,@Discount,@Quantity,@ExpDate,@ImageUrl,@Status)
	END
	IF @Type = 'Update'
	BEGIN
		UPDATE Medicines SET Name=@Name,Manufacturer=@Manufacturer,UnitPrice=@UnitPrice,Discount=@Discount,Quantity=@Quantity		
		WHERE ID = @ID;
	END
	IF @Type = 'Delete'
	BEGIN
		UPDATE Medicines SET Status = 0 WHERE ID = @ID;
	END
	IF @Type = 'Get'
	BEGIN
		SELECT * FROM Medicines WHERE Status = 1;
	END
	IF @Type = 'GetByID'
	BEGIN
		SELECT * FROM Medicines WHERE ID = @ID;
	END
END

CREATE PROC sp_UserList
AS
BEGIN
	SELECT ID, FirstName, LastName, Email, CASE WHEN Fund IS NULL THEN 0.00 ELSE FUND END AS FUND
	, CONVERT(NVARCHAR,CreatedON,107) AS OrderDate, Status, Password  FROM Users WHERE Status = 1 AND Type != 'Admin';
END;


CREATE PROC sp_updateOrderStatus(@OrderNo VARCHAR(100) = NULL, @OrderStatus VARCHAR(100) = NULL)
AS
BEGIN
	UPDATE Orders SET OrderStatus = @OrderStatus WHERE OrderNo = @OrderNo;
END

CREATE PROC sp_CartList(@Email VARCHAR(100))
AS
BEGIN
    IF @Email != 'Admin'
	BEGIN
		SELECT C.ID, M.Name, M.Manufacturer, M.UnitPrice, M.Discount, C.Quantity, C.TotalPrice, M.ImageUrl FROM Cart C 
		INNER JOIN Medicines M ON M.ID = C.MedicineID
		INNER JOIN Users U ON U.ID = C.UserId
		WHERE U.Email =  @Email;
	END
	ELSE
	BEGIN
		SELECT M.ID, M.Name, M.Manufacturer, M.UnitPrice, M.Discount, M.Quantity, M.ImageUrl , 0 AS TotalPrice FROM Medicines M;
	END
END;
